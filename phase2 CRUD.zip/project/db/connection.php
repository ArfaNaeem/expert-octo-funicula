<?php
	$dbserver="localhost";
	$username="root";
	$pass="abdullah764316";
	$dbname="schoolm";


/*$conn =  mysqli_connect($dbserver,$username,$pass,$dbname) or die('my sql server connection error:'.mysqli_connect_error());*/


	$conn = mysqli_connect("localhost","root","");
		if(!$conn) {
			die('error connecting databse' . mysqli_connect_error());
	}

	
	$db_select = mysqli_select_db($conn,"schoolm");
        if(!$db_select) {
		      die('Database selection failed: '. mysqli_error($conn));
		}


//or die('my sql server connection error:'.mysqli_connect_error());

?>