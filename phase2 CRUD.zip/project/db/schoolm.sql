-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 03, 2020 at 06:15 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `schoolm`
--

-- --------------------------------------------------------

--
-- Table structure for table `signup_user`
--

DROP TABLE IF EXISTS `signup_user`;
CREATE TABLE IF NOT EXISTS `signup_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(30) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `country` varchar(20) NOT NULL,
  `password` varchar(32) NOT NULL,
  `details` varchar(150) NOT NULL,
  `img` varchar(600) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=65 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup_user`
--

INSERT INTO `signup_user` (`id`, `fname`, `uname`, `email`, `gender`, `country`, `password`, `details`, `img`) VALUES
(1, 'abdullah irfan', 'ai123', 'm.abdullah179951@gmail.com', 'male', 'pakistan', 'qwerty', 'i am good boy', 'images/2.jpeg'),
(58, 'abdullah king', 'adnanbro', '12312@g.com', 'male', 'america', 'zxcvb', '	  	\r\n	  qwertyrewwdf', 'images/1.jpg'),
(55, 'adnan tahir', 'adnanbro', 'adnan.tahir@gmail.com', 'male', '', '1234', '	  	\r\n	  ', 'images/');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admins`
--

DROP TABLE IF EXISTS `tbl_admins`;
CREATE TABLE IF NOT EXISTS `tbl_admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(20) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `img` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admins`
--

INSERT INTO `tbl_admins` (`id`, `fname`, `uname`, `email`, `pass`, `img`) VALUES
(1, 'abdullah', 'aii123', 'm.abdullah179951@gmail.com', '12345', 'images/'),
(2, 'hassan', 'hassan123', 'hassan@gmail.com', 'hassan123', 'images/3.jpg'),
(3, 'king', 'pakking12', '12312@g.com', 'abcc', 'images/kings.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact`
--

DROP TABLE IF EXISTS `tbl_contact`;
CREATE TABLE IF NOT EXISTS `tbl_contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `number` int(20) NOT NULL,
  `details` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_contact`
--

INSERT INTO `tbl_contact` (`id`, `name`, `email`, `number`, `details`) VALUES
(1, 'abdullah', 'm.abdullah179951@gmail.com', 12332, '	  	\r\n	  werrewr'),
(2, 'abdullah', 'm.abdullah179951@gmail.com', 12332, '	  	\r\n	  werrewr'),
(3, 'abdullah', 'mahnoor.irfan2002@gmail.com', 1234432, '	  	\r\n	  asddfs'),
(4, 'abdullah', 'm.abdullah179951@gmail.com', 1234532, '	 sdfsdf 	\r\n	  '),
(5, 'abdullah', 'mahnoor.irfan2002@gmail.com', 543223456, '	  	\r\n	  sdfgds'),
(6, 'abdullah', 'mahnoor.irfan2002@gmail.com', 2345432, '	  	\r\n	  asdfgfs'),
(7, 'abdullah', 'mahnoor.irfan2002@gmail.com', 123454322, 'qwere12323'),
(8, 'abdullah', 'mahnoor.irfan2002@gmail.com', 1234532, 'ert1234wsad'),
(9, 'abdullah', 'mahnoor.irfan2002@gmail.com', 1234532, 'ert1234wsad'),
(10, 'abdullah', 'mahnoor.irfan2002@gmail.com', 123432, 'qwert2345d'),
(11, 'abdullah', 'mahnoor.irfan2002@gmail.com', 123432, 'qwert2345d'),
(12, 'abdullah', 'mahnoor.irfan2002@gmail.com', 123432, 'qwert2345d'),
(13, 'abdullah', 'm.abdullah179951@gmail.com', 25543221, 'asdfdsadf'),
(14, 'abdullah', 'm.abdullah179951@gmail.com', 23453, 'sdsasd'),
(15, 'abdullah', 'm.abdullah179951@gmail.com', 21345, 'sdfs234w'),
(16, 'abdullah', 'm.abdullah179951@gmail.com', 23453, 'sdfsdf'),
(17, 'abdullah king', 'mahnoor.irfan2002@gmail.com', 1234543213, '12345sdfds'),
(18, 'king', 'pakking@gmail.com', 1234212342, '3454323werdsd'),
(19, '12', 'sdaasasdco@s.com', 2131, '12312'),
(20, 'abdullah', 'mahnoor.irfan2002@gmail.com', 777777777, '23423e23e'),
(21, '12', 'mahnoor.irfan2002@gmail.com', 23534343, '2131s'),
(22, '12', 'mahnoor.irfan2002@gmail.com', 23534343, '2131s'),
(23, '12', 'mahnoor.irfan2002@gmail.com', 1234432, '5r4e345t'),
(24, '12', '2342213@g.co', 123123, '2e2e12'),
(25, '12', '12312@g.com', 12312, 's2121s2');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_gameplays`
--

DROP TABLE IF EXISTS `tbl_gameplays`;
CREATE TABLE IF NOT EXISTS `tbl_gameplays` (
  `gp_id` int(11) NOT NULL AUTO_INCREMENT,
  `gp_img` varchar(100) NOT NULL,
  `gp_desc` varchar(2000) NOT NULL,
  PRIMARY KEY (`gp_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_gameplays`
--

INSERT INTO `tbl_gameplays` (`gp_id`, `gp_img`, `gp_desc`) VALUES
(1, 'images/gif2.gif', 'what a good boys'),
(2, 'images/gif2.gif', 'what a good boys'),
(3, 'images/5.jpg', 'what an entry'),
(4, 'images/5.jpg', 'sdfghwergh');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_products`
--

DROP TABLE IF EXISTS `tbl_products`;
CREATE TABLE IF NOT EXISTS `tbl_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prod_name` varchar(30) NOT NULL,
  `prod_size` varchar(30) NOT NULL,
  `prod_price` varchar(20) NOT NULL,
  `prod_discount` varchar(30) NOT NULL,
  `prod_details` varchar(1000) NOT NULL,
  `prod_img` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_products`
--

INSERT INTO `tbl_products` (`id`, `prod_name`, `prod_size`, `prod_price`, `prod_discount`, `prod_details`, `prod_img`) VALUES
(1, 'Cherry Blossom Pink', 'large', '1080', '30%', 'Compete with 100 players on a remote island for a winner-takes-all showdown where strategic gameplay is as important as shooting skills.Compete with 100 players on a remote island for a winner-takes-all showdown where strategic gameplay is as important as shooting skills.Compete with 100 players on a remote island for a winner-takes-all showdown where strategic gameplay is as important as shooting skills.Compete with 100 players on a remote island for a winner-takes-all showdown where strategic gameplay is as important as shooting skills.', 'images/product-img-1'),
(2, 'exotic design', 'large', '1080', '30%', 'it is good', 'images/product-img-2'),
(3, 'exotic design', 'large', '1080', '30%', 'it is good', 'images/product-img-3'),
(4, 'exotic design', 'large', '1080', '30%', 'it is good', 'images/product-img-4'),
(5, 'exotic design', 'large', '1080', '30%', 'it is good', 'images/product-img-5'),
(6, 'exotic design', 'large', '1080', '30%', 'it is good', 'images/product-img-6'),
(7, 'exotic design', 'large', '1080', '30%', 'it is good', 'images/product-img-7'),
(8, 'exotic design', 'large', '1080', '30%', 'it is good', 'images/product-img-8'),
(9, 'exotic design', 'large', '1080', '30%', 'it is good', 'images/product-img-9'),
(11, 'kings', 'medium', '12', '12%', 'qweqweq', 'images/Windows_10_4k_Wallpapers-1.jpg');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
