


<?php require 'header.php'; ?>
<?php require('nav.php') ?>


<div class="news-page">
		<div class="container">
			<div class="news-div">
				<div class="row" >
					<div class="news-left">
						<div class="img-left">
							<div class="img-tabs hovereffect">
								<img class="img-responsive" src="images/img0.png" height="400px" alt="">
							</div>
						</div>
					</div>
					<div class="news-right">					
						<div class="right-detail news-page-tabs hovereffects">
							<h6>Player Unknown Battle Ground</h6>
							<p>PlayerUnknown's Battlegrounds is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole.PlayerUnknown's Battlegrounds is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole.PlayerUnknown's Battlegrounds is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole.PlayerUnknown's Battlegrounds is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole.</p>

									<div class="overlay">
										<h2><a href="product-1.html">read more</a></h2>
									</div>

						</div>
					</div>					
				</div>
			</div>
			<div class="news-div">
				<div class="row" >
					<div class="news-left">
						<div class="img-left">
							<div class="img-tabs hovereffect">
								<img class="img-responsive" src="images/img0.png" height="400px" alt="">
							</div>
						</div>
					</div>
					<div class="news-right">					
						<div class="right-detail news-page-tabs hovereffects">
							<h6>Player Unknown Battle Ground</h6>
							<p>PlayerUnknown's Battlegrounds is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole.PlayerUnknown's Battlegrounds is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole.PlayerUnknown's Battlegrounds is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole.PlayerUnknown's Battlegrounds is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole.</p>

									<div class="overlay">
										<h2><a href="product-1.html">read more</a></h2>
									</div>

						</div>
					</div>					
				</div>
			</div>
			<div class="news-div">
				<div class="row" >
					<div class="news-left">
						<div class="img-left">
							<div class="img-tabs hovereffect">
								<img class="img-responsive" src="images/img0.png" height="400px" alt="">
							</div>
						</div>
					</div>
					<div class="news-right">					
						<div class="right-detail news-page-tabs hovereffects">
							<h6>Player Unknown Battle Ground</h6>
							<p>PlayerUnknown's Battlegrounds is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole.PlayerUnknown's Battlegrounds is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole.PlayerUnknown's Battlegrounds is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole.PlayerUnknown's Battlegrounds is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole.</p>

									<div class="overlay">
										<h2><a href="product-1.html">read more</a></h2>
									</div>

						</div>
					</div>					
				</div>
			</div>
			<div class="news-div">
				<div class="row" >
					<div class="news-left">
						<div class="img-left">
							<div class="img-tabs hovereffect">
								<img class="img-responsive" src="images/img0.png" height="400px" alt="">
							</div>
						</div>
					</div>
					<div class="news-right">					
						<div class="right-detail news-page-tabs hovereffects">
							<h6>Player Unknown Battle Ground</h6>
							<p>PlayerUnknown's Battlegrounds is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole.PlayerUnknown's Battlegrounds is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole.PlayerUnknown's Battlegrounds is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole.PlayerUnknown's Battlegrounds is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole.</p>

									<div class="overlay">
										<h2><a href="product-1.html">read more</a></h2>
									</div>

						</div>
					</div>					
				</div>
			</div>
			<div class="news-div">
				<div class="row" >
					<div class="news-left">
						<div class="img-left">
							<div class="img-tabs hovereffect">
								<img class="img-responsive" src="images/img0.png" height="400px" alt="">
							</div>
						</div>
					</div>
					<div class="news-right">					
						<div class="right-detail news-page-tabs hovereffects">
							<h6>Player Unknown Battle Ground</h6>
							<p>PlayerUnknown's Battlegrounds is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole.PlayerUnknown's Battlegrounds is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole.PlayerUnknown's Battlegrounds is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole.PlayerUnknown's Battlegrounds is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole.</p>

									<div class="overlay">
										<h2><a href="product-1.html">read more</a></h2>
									</div>

						</div>
					</div>					
				</div>
			</div>
			<div class="news-div">
				<div class="row" >
					<div class="news-left">
						<div class="img-left">
							<div class="img-tabs hovereffect">
								<img class="img-responsive" src="images/img0.png" height="400px" alt="">
							</div>
						</div>
					</div>
					<div class="news-right">					
						<div class="right-detail news-page-tabs hovereffects">
							<h6>Player Unknown Battle Ground</h6>
							<p>PlayerUnknown's Battlegrounds is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole.PlayerUnknown's Battlegrounds is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole.PlayerUnknown's Battlegrounds is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole.PlayerUnknown's Battlegrounds is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole.</p>

									<div class="overlay">
										<h2><a href="product-1.html">read more</a></h2>
									</div>

						</div>
					</div>					
				</div>
			</div>
			<div class="news-div">
				<div class="row" >
					<div class="news-left">
						<div class="img-left">
							<div class="img-tabs hovereffect">
								<img class="img-responsive" src="images/img0.png" height="400px" alt="">
							</div>
						</div>
					</div>
					<div class="news-right">					
						<div class="right-detail news-page-tabs hovereffects">
							<h6>Player Unknown Battle Ground</h6>
							<p>PlayerUnknown's Battlegrounds is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole.PlayerUnknown's Battlegrounds is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole.PlayerUnknown's Battlegrounds is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole.PlayerUnknown's Battlegrounds is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole.</p>

									<div class="overlay">
										<h2><a href="product-1.html">read more</a></h2>
									</div>

						</div>
					</div>					
				</div>
			</div>
		</div>
	</div>
	
	<div class="pubg-logos">
		<div class="container">
			<div class="row">
				
			</div>
		</div>
	</div>


<?php require 'footer.php'; ?>