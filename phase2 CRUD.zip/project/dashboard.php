<div class="col-md-2 col-sm-2 col-lg-2 col-xs-2">
	<div class="navs">		  
		  
			<div class="container">
				<h4>Dashboard</h4>
				<ul>
				  <li class="nav-item ">
					<a href="welcome.php">main</a>
				  </li>
				  <li class="nav-item">
					<a href="view_products.php">View Products</a>
				  </li>
				  <li class="nav-item">
					<a  href="add_product.php">ADD Products</a>
				  </li>
				  <li class="nav-item">
					<a  href="view_admin.php">View Admins</a>
				  </li>
				  <li class="nav-item">
					<a  href="view_signup.php">View signup</a>
				  </li>
				  <li class="nav-item">
					<a  href="add_signup.php">signup</a>
				  </li>
				  
				  <li class="nav-item">
					<a  href="add_gameplays.php">Add gamplays</a>
				  </li>
				  <li class="nav-item">
					<a  href="view_gameplays.php">View gameplay</a>
				  </li>
				  <li class="nav-item">
					<a  href="products.php">Product-detail</a>
				  </li>
				  <li class="nav-item">
					<a href="contacted.php">Contact Us</a>
				  </li>
				  <li class="nav-item">
					<a href="admin.php">Admin Login</a>
				  </li>
					   
				</ul>
			</div>
				
			  
</div>	
	
</div>

