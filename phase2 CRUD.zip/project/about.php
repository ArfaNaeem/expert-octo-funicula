
<?php require 'header.php'; ?>
<?php require('nav.php') ?>





<div class="about-section">
		<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h2>About Us</h2>
	  			<p>Gameplay. Battlegrounds is a player versus player shooter game in which up to one hundred players fight in a battle royale, a type of large-scale last man standing deathmatch where players fight to remain the last alive. Players can choose to enter the match solo, duo, or with a small team of up to four people.
					PlayerUnknown's Battlegrounds is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole.
					PlayerUnknown's Battlegrounds (PUBG) is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole. The game is based on previous mods that were created by Brendan "PlayerUnknown" Greene for other games, inspired by the 2000 Japanese film Battle Royale, and expanded into a standalone game under Greene's creative direction. In the game, up to one hundred players parachute onto an island and scavenge for weapons and equipment to kill others while avoiding getting killed themselves. The available safe area of the game's map decreases in size over time, directing surviving players into tighter areas to force encounters. The last player or team standing wins the round.
				</p>
			</div>
		</div>
	  
		  <div class="embed-responsive embed-responsive-item">
			<iframe width="800px" height="500px" class="embed-responsive-item"  src="https://www.youtube.com/embed/DKEPMAdzwE0"></iframe>
		  </div>
			<p>Gameplay. Battlegrounds is a player versus player shooter game in which up to one hundred players fight in a battle royale, a type of large-scale last man standing deathmatch where players fight to remain the last alive. Players can choose to enter the match solo, duo, or with a small team of up to four people.
					PlayerUnknown's Battlegrounds is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole.
					PlayerUnknown's Battlegrounds (PUBG) is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole. The game is based on previous mods that were created by Brendan "PlayerUnknown" Greene for other games, inspired by the 2000 Japanese film Battle Royale, and expanded into a standalone game under Greene's creative direction. In the game, up to one hundred players parachute onto an island and scavenge for weapons and equipment to kill others while avoiding getting killed themselves. The available safe area of the game's map decreases in size over time, directing surviving players into tighter areas to force encounters. The last player or team standing wins the round.
				</p>
		
</div>
	</div>
	
	<div class="heading" style="border-bottom: 3px solid orange">
		<div class="container">
			<div class="row">
				<div class="col-md-4">
					<p><i>PLAY TODAY ON XBOX, PC, AND PS4</i></p>
				</div>
			<div class="col-md-8">
				<ul>
					<li><a href="#"><img src="images/heading-img1.png" alt="img1"></a></li>
					<li><a href="#"><img src="images/heading-img2.png" alt="img1"></a></li>
					<li><a href="#"><img src="images/heading-img3.png" alt="img1"></a></li>
				</ul>
			</div>
 		  </div>		
		</div>
	</div>

<?php require 'footer.php'; ?>


	