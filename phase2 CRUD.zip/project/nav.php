<nav class="navbar navbar-expand-md">		  
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
				<span class="navbar-toggler"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
		  </button>
			
			<div class="container">
				<div class="collapse navbar-collapse" id="collapsibleNavbar">
				<ul class="navbar-nav">
				  <li class="nav-item">
					<a href="index.php">HOME</a>
				  </li>
				  <li class="nav-item">
					<a  href="about.php">About-us</a>
				  </li>
				  <li class="nav-item">
					<a href="products.php">Products</a>
				  </li>
				  <li class="nav-item">
					<a  href="news.php">News</a>
				  </li>
				  <li class="nav-item">
					<a  href="gameplays.php">gameplay</a>
				  </li>
				  <li class="nav-item">
					<a  href="products.php">Product-detail</a>
				  </li>
				  <li class="nav-item">
					<a href="contacted.php">Contact Us</a>
				  </li>
				  <li class="nav-item">
					<a href="admin.php">Admin Login</a>
				  </li>
					   
				</ul>
			</div>	
			</div>
			  
</nav>