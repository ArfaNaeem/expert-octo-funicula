<footer>
		<div class="container">
			<div class="row">
			<div class="col-md-10">
					<img src="images/footer-logo.png" alt="footer-logo" height="150px">
					
					<p>PLAYERUNKNOWN’S BATTLEGROUNDS and PUBG are registered trademarks, trademarks or service marks of PUBG CORPORATION.</p>
					<p>Partnership Inquiry: <a href="#">PUBG_inquiry@pubg.com</a></p>
					<ul >
						<li>Privacy Policy:</li>    
						<li><a href="#">Terms of Service</a></li>
						<li><a href="#">Rules of Conduct</a></li>
						<li><a href="#">EULA</a></li>
						<li><a href="#">Player-created Content</a></li>
					</ul>
				
			</div>
			<div class="col-md-2">
					<img src="images/footer-logo-right.png" alt="footer-right">
			</div>
		</div>
			<div class="row">
			<div class="col-md-12">
				<div class="footers">
					<p>COPYRIGHT <span>2020 PUBG</span> CORPORATION. ALL RIGHTS RESERVED.</p>
				</div>
			</div>
		</div>			
		</div>
	</footer>
<script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>


<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(e) {
  if (!e.target.matches('.dropbtn')) {
  var myDropdown = document.getElementById("myDropdown");
    if (myDropdown.classList.contains('show')) {
      myDropdown.classList.remove('show');
    }
  }
}
</script>
