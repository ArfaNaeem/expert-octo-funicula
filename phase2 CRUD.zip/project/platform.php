<div class="platform-section">
		<div class="container">
		 	<div class="row">
			 	 <div class="col-md-5">
					
				</div>
			 	 <div class="col-md-7">
					 <h1>PLAY TODAY ON XBOX, PC, AND PS4</h1>
					 <p>Compete with 100 players on a remote island for a winner-takes-all showdown where strategic gameplay is as important as shooting skills.</p>
					<ul class="button-list">
					<li><a href="#"><img src="images/heading-img1.png" class="img-responsive" alt="img1"></a></li>
					<li><a href="#"><img src="images/heading-img2.png" class="img-responsive"  alt="img1"></a></li>
					<li><a href="#"><img src="images/heading-img3.png" class="img-responsive"  alt="img1"></a></li>
				</ul>
				</div>
			</div>
		</div>
	</div>